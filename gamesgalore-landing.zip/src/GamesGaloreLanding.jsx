import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Smartphone, Star, Gamepad2, Globe2, Zap, Gamepad } from "lucide-react";

export default function GamesGaloreLanding() {
  return (
    <div className="relative min-h-screen bg-gradient-to-b from-blue-800 via-gray-900 to-black text-white overflow-hidden">
      <motion.div className="absolute inset-0 pointer-events-none z-0">
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute text-blue-500 opacity-50 drop-shadow-[0_0_8px_#3b82f6]"
            initial={{ x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight }}
            animate={{
              y: [Math.random() * window.innerHeight, Math.random() * window.innerHeight],
              x: [Math.random() * window.innerWidth, Math.random() * window.innerWidth],
              rotate: [0, 360],
              scale: [1, 1.2, 1],
              opacity: [0.4, 0.8, 0.4],
            }}
            transition={{ duration: 12 + Math.random() * 8, repeat: Infinity, ease: "easeInOut" }}
          >
            <Gamepad className="w-12 h-12" />
          </motion.div>
        ))}
      </motion.div>

      <section className="relative text-center py-20 px-6 z-10">
        <motion.h1
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-5xl font-extrabold mb-4 text-blue-400 drop-shadow-[0_0_10px_#3b82f6]"
        >
          Power Up Your Fun!
        </motion.h1>
        <p className="text-lg mb-8 max-w-2xl mx-auto text-gray-300">
          GamesGalore delivers action-packed, addicting games designed for the guys who love to play and compete.
        </p>
        <div className="flex justify-center gap-4">
          <Button className="group relative bg-blue-600 text-white px-6 py-3 rounded-2xl shadow-lg transition duration-300 overflow-hidden">
            <span className="relative z-10">Download on App Store</span>
            <span className="absolute inset-0 rounded-2xl bg-blue-400 opacity-0 group-hover:opacity-100 blur-md transition duration-300"></span>
          </Button>
          <Button className="group relative bg-green-600 text-white px-6 py-3 rounded-2xl shadow-lg transition duration-300 overflow-hidden">
            <span className="relative z-10">Get it on Google Play</span>
            <span className="absolute inset-0 rounded-2xl bg-green-400 opacity-0 group-hover:opacity-100 blur-md transition duration-300"></span>
          </Button>
        </div>
      </section>
    </div>
  );
}