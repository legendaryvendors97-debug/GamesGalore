import GamesGaloreLanding from "./GamesGaloreLanding";

function App() {
  return <GamesGaloreLanding />;
}

export default App;
